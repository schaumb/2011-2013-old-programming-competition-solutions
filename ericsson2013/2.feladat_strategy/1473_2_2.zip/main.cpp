#include "object.hpp"
#include "WorldStatusUpdate.pb.h"
#include "Commands.pb.h"
#include "ProtobufUtil.hh"



using namespace strategy_protocol;
using namespace protoutil;
using namespace std;

int step = 1;

void calcCMDS(const WorldStatusUpdate& w, Commands& cmds, GlobalState &st){
	//Először frissítjük az objektumokat
	
	LOG1("begin read");
	//resource
	if(w.has_resource()){
		st.resource = w.resource();
	}
	//boss
	if(w.bosses_size()!=0 && st.boss==0){
		st.boss = new Boss(w.bosses(0));
		st.state = BOSS;
	}
	else if(w.bosses_size()!=0 && st.boss!=0){
		*st.boss = w.bosses(0);
	}
	
	//workers
	for(int i=0; i<w.workers_size(); ++i){
		st.workers[w.workers(i).common().id()] = w.workers(i);
		st.workers[w.workers(i).common().id()].setRound(step);
	}
	
	//soldiers
	
	for(int i=0; i<w.soldiers_size(); ++i){
		st.soldiers[w.soldiers(i).common().id()] = w.soldiers(i);
		st.soldiers[w.soldiers(i).common().id()].setRound(step);
	}
	
	//mines
	
	for(int i=0; i<w.mines_size(); ++i){
		st.mines[w.mines(i).common().id()] = w.mines(i);
		st.mines[w.mines(i).common().id()].setRound(step);
	}
	
	//minions
	st.minions.clear();
	for(int i=0; i<w.minions_size(); ++i){
		st.minions[w.minions(i).common().id()] = w.minions(i);
	}
	
	LOG1("end read");
	LOG1("start update");
	
	//Ha van idő TODO ne keljen
	for(int i=0; i<w.obstacles_size(); ++i){
		st.obstacles[w.obstacles(i).common().id()] = w.obstacles(i).common();
	}
	//IDE jöhet a state globális módosításai
	int mySoldierCountNearBoss = 0;
	bool allSoldierNearIsLocked = true;
	if( st.boss!=0 )
	{
		for(const auto& it : st.soldiers){
			int dist = distance(it.second.Position(),st.boss->Position());
			if(dist < 8) 
			{
				allSoldierNearIsLocked&= it.second.IsLocked();
				++mySoldierCountNearBoss;
			}
		}
	}
	
    if(st.boss != NULL && st.state < BOSS)
	{
        st.state=BOSS;
	}
	else if(st.state == QUIESCENCE && st.minions.size()*0.75 > st.soldiers.size()){
		st.state = ATTACK;
	}
	else if(st.state == ATTACK && st.minions.size()*0.5 < st.soldiers.size()){
		st.state = QUIESCENCE;
	}
	else if(  st.state == BOSS &&( mySoldierCountNearBoss > 6 || ( allSoldierNearIsLocked && mySoldierCountNearBoss > 0 )  ))
	{
		st.state = ATTACK_THE_BOSS;
	}
	else if ( st.state == ATTACK_THE_BOSS  && mySoldierCountNearBoss == 0)
	{
		st.state = BOSS;
	}

	PRINTTABLE(st)

	//Minden comander objektumot megkérünk, hogy fűzzön hozzá parancsot
	st.base.AddToCommands(st,cmds);
	
	for(auto i = st.mines.begin(); i != st.mines.end(); ){
		if(i->second.Capacity() == 0){
			LOG2("EMPTY ",i->second.Id());
			st.mines.erase(i++);
		}
		else{
			++i;
		}
	}
	
	for(auto i = st.workers.begin(); i != st.workers.end(); ){
		if(i->second.getRound() == step){
            std::cerr << i->first << std::endl;
			i->second.AddToCommands(st,cmds);
			++i;
		}
		else{
			LOG2("DIED ",i->second.Id());
			st.workers.erase(i++);
		}
	}
	
	for(auto i = st.soldiers.begin(); i != st.soldiers.end(); ){
		if(i->second.getRound() == step){
			i->second.AddToCommands(st,cmds);
			++i;
		}
		else{
			LOG2("DIED ",i->second.Id());
			st.soldiers.erase(i++);
		}
	}
	LOG1("end updating")
}

int main(){
	
	
	GlobalState st;
	st.state = QUIESCENCE;
	WorldStatusUpdate world;
	//Elő Olvasunk, hogy a bázist beállítsuk
	readProtoFromStream(world, cin);
	st.base = world.bases(0);
	
	Commands commands;
	//Parancsok előállítása
	calcCMDS(world, commands, st);
	//Elküldjük a parancsokat
	writeProtoOnStream(commands, cout);
	while (cin.good()) {

		//Olvasunk
		readProtoFromStream(world, cin);

		//cerr << "Tick: " << step << endl;
		//cerr << "Proto content with DebugString" << endl;
		//cerr << world.DebugString() << endl;
		commander::reset();
		Commands commands;
		commander::AddDummyCommand(commands);
		//kiszámítjuk a parancsokat
		calcCMDS(world, commands, st);
		//Elküldjük a parancsokat
		writeProtoOnStream(commands, cout);

		++step;
		
		//PRINTTABLE(st)
		
	}
	return 0;
}
