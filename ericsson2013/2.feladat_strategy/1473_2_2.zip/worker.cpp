#include "object.hpp"

#define MAX_RESOURCE 10

void Worker::AddToCommands(GlobalState& st,strategy_protocol::Commands& cmds){
    std::string mine_id = "";
    v next_step;
    if(mine!=0 && distance(Position(), mine->Position()) <=1 && mine->Capacity() <= 0)
        State(SEARCH_MINE);

    for(auto i = st.minions.begin(); i != st.minions.end(); ++i){
        if(distance(i->second.Position(), Position()) < 3 && Resource() == 0){
            Attack(cmds, i->second.Id());
            return;
        }
    }
    switch(state)
    {
        case WORKING:
            if(Position() == mine->Position() && Resource() ==  MAX_RESOURCE){ //Kérdezés
                //route=mine->getReversRout();
                route=std::queue<v>();
                route.push(st.base.Position()); //ez és az előző!!!
                real_route.push(mine->Position());
                mine->addHint(real_route);
                next_step = nextStep(st);
                Move(cmds, next_step.X, next_step.Y);
                break;
            }
            if(distance(Position(), st.base.Position()) == 1 && Resource() == 0){
                //route=mine->getRout(); 
                route=std::queue<v>();
                route.push(mine->Position()); //ez és az előző!!!
                //if(route.size() > 1){
                //    route.pop();
                //}
                real_route=std::queue<v>();
                real_route.push(st.base.Position());
                next_step = nextStep(st);
                Move(cmds, next_step.X, next_step.Y);
                break;
            }
            else{//Útközben
                next_step = nextStep(st);
                Move(cmds, next_step.X, next_step.Y);
                break;
            }

        case SEARCH_MINE:
            mine = 0;
            if(!st.mines.empty()){
                for(auto i = st.mines.begin(); i != st.mines.end();++i){
                    if(i->second.CanAddWorker() && i->second.Capacity() > 0){
                        mine_id=i->first;
                        State(WORKING);
                        iteration=0;
                        break;
                    }
                }
                if(mine_id!=""){
                    AddMine(&st.mines[mine_id]);
                    //route=mine->getRout();
                    route=std::queue<v>();
                    route.push(mine->Position()); //ez és az előző!!!
                    real_route=std::queue<v>();
                    real_route.push(st.base.Position());
                }
            }
            else{
                if(route.empty())
                    Iterate(st, cmds);
            }
            next_step=nextStep(st);
            Move(cmds, next_step.X, next_step.Y);
            break; 
    }
}

void Worker::Iterate(GlobalState &st, strategy_protocol::Commands& cmds){
    v next_step;
    if(iteration==0){
        int d=rand()%4;
        switch(d)
        {
            case 0:
                direction_vector=v(0,12);
                break;
            case 1:
                direction_vector=v(12,0);
                break;
            case 2:
                direction_vector=v(0,-12);
                break;
            case 3:
                direction_vector=v(-12,0);
                break;
        }
        route.push(Position()+direction_vector);
        next_step=nextStep(st);
        Move(cmds, next_step.X, next_step.Y);
		++iteration;
    }
    else{
       switch(iteration%4)
       {
            case 0:
                route.push(Position()+v(iteration*direction_vector.Y, -iteration*direction_vector.X));
                break;
            case 1:
                route.push(Position()+direction_vector+v(direction_vector.Y,-direction_vector.X));
                break;
            case 2:
                route.push(Position()+v(-iteration*direction_vector.Y, iteration*direction_vector.X));
                break;
            case 3:
                route.push(Position()+direction_vector+v(-direction_vector.Y,direction_vector.X));
                break;
       }
	   ++iteration;
    }
}

Worker::~Worker()
{
{
        if(mine!=NULL)
            mine->DieWorker();
        if(buddy!=NULL)
            buddy->UnGuard();
    }
}

void Worker::UnGuard()
{
    if(guarded){
        guarded=false;
        if(buddy!=NULL){
            buddy->UnGuard();
            buddy=NULL;
        }
    }
}
