#include "object.hpp"


void commander::Attack(strategy_protocol::Commands& cmds,const std::string& what,const std::string& id){
		++counter;
		LOG4("ATTACK " ,id,"->",what);
		auto command = cmds.add_commands();
		command->set_commandtype(strategy_protocol::Commands::ATTACK);
		auto attack = command->mutable_attackcommand();
		attack-> set_withwhat(id);
		attack-> set_what(what);
	}
	
void commander::Move(strategy_protocol::Commands& cmds,int x, int y, const std::string& id){
		++counter;
		auto command = cmds.add_commands();
		command->set_commandtype(strategy_protocol::Commands::MOVE);
		auto move = command->mutable_movecommand();
		move->set_withwhat(id);
		auto pos = move->mutable_toposition();
		pos->set_x(x);
		pos->set_y(y);
		
	}
	
void commander::TrainSoldier(strategy_protocol::Commands& cmds,const  std::string& id){
		++counter;
		auto command = cmds.add_commands();
		command->set_commandtype(strategy_protocol::Commands::TRAIN);
		auto train = command->mutable_traincommand();
		train->set_withwhat(id);
		train->set_what(strategy_protocol::Commands::SOLDIER);
	}
void commander::TrainWorker(strategy_protocol::Commands& cmds,const  std::string& id){
		++counter;
		auto command = cmds.add_commands();
		command->set_commandtype(strategy_protocol::Commands::TRAIN);
		auto train = command->mutable_traincommand();
		train->set_withwhat(id);
		train->set_what(strategy_protocol::Commands::WORKER);
	}

int commander::counter;
